#include "seg_display_lib.h"



void wipe(int din, int cs, int clk){
digitalWrite(cs,LOW);
shiftOut(din,clk,MSBFIRST,0xff);
shiftOut(din,clk,MSBFIRST,0x00);
digitalWrite(cs,HIGH);
}

void shut_dwn(int din, int cs, int clk){
digitalWrite(cs,LOW);
shiftOut(din,clk,MSBFIRST,0xfc);
shiftOut(din,clk,MSBFIRST,0x01);
digitalWrite(cs,HIGH);
}

void set_bright(int level,int din, int cs, int clk){
int a[16]={0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f}; 
digitalWrite(cs,LOW);
shiftOut(din,clk,MSBFIRST,0x0a);
shiftOut(din,clk,MSBFIRST,a[level]);
digitalWrite(cs,HIGH);
}

void decode_mode(int din, int cs, int clk){
digitalWrite(cs,LOW);
shiftOut(din,clk,MSBFIRST,0x09);
shiftOut(din,clk,MSBFIRST,0x00);
digitalWrite(cs,HIGH); 
}

void seg_dis(unsigned char a[],int din, int cs, int clk){
 unsigned char dig[8]={0x08,0x07,0x06,0x05,0x04,0x03,0x02,0x01};
 int i;
 for(i=0;a[i]!='\0';i++){
  digitalWrite(cs,LOW);
  shiftOut(din,clk,MSBFIRST,dig[i]);
  show_up(a[i],din,cs,clk);
  digitalWrite(cs,HIGH); 
 }
}

void show_up(unsigned char w,int din, int cs, int clk){
  switch(w){
    case '1': shiftOut(din,clk,MSBFIRST,0x30); break;
    case '2': shiftOut(din,clk,MSBFIRST,0x6d); break;
    case '3': shiftOut(din,clk,MSBFIRST,0x79); break;
    case '4': shiftOut(din,clk,MSBFIRST,0x33); break;
    case '5': shiftOut(din,clk,MSBFIRST,0x5b); break;
    case '6': shiftOut(din,clk,MSBFIRST,0x5f); break;
    case '7': shiftOut(din,clk,MSBFIRST,0x70); break;
    case '8': shiftOut(din,clk,MSBFIRST,0x7f); break;
    case '9': shiftOut(din,clk,MSBFIRST,0x7b); break;
    case '0': shiftOut(din,clk,MSBFIRST,0x7e); break;
    case 'A': shiftOut(din,clk,MSBFIRST,0x77); break;
    case 'H': shiftOut(din,clk,MSBFIRST,0x37); break;
    case 'P': shiftOut(din,clk,MSBFIRST,0x67); break;
    case 'Y': shiftOut(din,clk,MSBFIRST,0x3b); break; 
    case 'L': shiftOut(din,clk,MSBFIRST,0x0e); break;
    case 'F': shiftOut(din,clk,MSBFIRST,0x47); break;
    case 'E': shiftOut(din,clk,MSBFIRST,0x4f); break;
    case '.': shiftOut(din,clk,MSBFIRST,0x80); break;
    default: shiftOut(din,clk,MSBFIRST,0x00); break;
}
}

void disp(int num,int din, int cs, int clk){
  int ld;
  int pos = 7;
  unsigned char p[8];
  while(num!=0){
    ld = num%10;
    switch(ld){
      case 1: p[pos]='1'; pos--; break;
      case 2: p[pos]='2'; pos--; break;
      case 3: p[pos]='3'; pos--; break;
      case 4: p[pos]='4'; pos--; break;
      case 5: p[pos]='5'; pos--; break;
      case 6: p[pos]='6'; pos--; break;
      case 7: p[pos]='7'; pos--; break;
      case 8: p[pos]='8'; pos--; break;
      case 9: p[pos]='9'; pos--; break;
      case 0: p[pos]='0'; pos--; break;
    }
    num = num/10;
  }
  while(pos!=-1){
    p[pos]='a';
    pos--;
  }
  delay(5);
  seg_dis(p, din, cs, clk);
}

void set_scan(int din, int cs, int clk){
  digitalWrite(cs,LOW);
  shiftOut(din,clk,MSBFIRST,0x0b);
  shiftOut(din,clk,MSBFIRST,0x07);
  digitalWrite(cs,HIGH); 
}

void disp_init(int din, int cs, int clk){
  decode_mode(din,cs,clk);
  set_bright(7,din,cs,clk);
  set_scan(din,cs,clk);
  wipe(din,cs,clk);
  shut_dwn(din,cs,clk);
}
