#ifndef SEG_DISPLAY_LIB_H
#define SEG_DISPLAY_LIB_H

#include<Arduino.h>
void wipe(int din, int cs, int clk);
void shut_dwn(int din, int cs, int clk);
void set_bright(int level,int din, int cs, int clk);
void decode_mode(int din, int cs, int clk);
void seg_dis(unsigned char a[],int din, int cs, int clk);
void show_up(unsigned char w,int din, int cs, int clk);
void disp(int num,int din, int cs, int clk);
void set_scan(int din, int cs, int clk);
void disp_init(int din, int cs, int clk);

#endif
